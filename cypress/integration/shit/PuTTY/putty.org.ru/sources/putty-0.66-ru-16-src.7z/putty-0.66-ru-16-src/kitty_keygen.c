int get_param( const char * val ) { return 0 ; }
void debug_logevent( const char *fmt, ... ) { return ; }