enum cthelper_exitcode {
  CthelperSuccess = 0,
  CthelperInvalidUsage,
  CthelperInvalidPort,
  CthelperConnectFailed,
  CthelperPtyforkFailure,
  CthelperExecFailure,
};
