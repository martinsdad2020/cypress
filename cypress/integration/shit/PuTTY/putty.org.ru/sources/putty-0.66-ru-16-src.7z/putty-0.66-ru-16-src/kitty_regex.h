#ifndef KITTY_REGEX
#define KITTY_REGEX
#include <stdlib.h>
#include "regex.h"
int strgrep( const char * pattern, const char * str ) ;
#endif
