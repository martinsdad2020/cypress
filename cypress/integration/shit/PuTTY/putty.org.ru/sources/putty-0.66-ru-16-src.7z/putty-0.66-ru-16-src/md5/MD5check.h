#include <windows.h>

/* Procedure de v�rification de la signature */
BOOL CheckMD5Integrity(void) ;
